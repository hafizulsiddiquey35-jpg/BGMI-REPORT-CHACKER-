/**
 * BGMI UPDATE MONITOR - server.js
 *
 * This server ONLY queries Google's public Custom Search JSON API for
 * publicly available news/pages about BGMI updates, patch notes, and
 * security/anti-cheat announcements. It does not access, query, or
 * attempt to bypass any BGMI private servers, private APIs, player
 * accounts, ban systems, game files, or internal anti-cheat systems.
 */

require('dotenv').config();
const express = require('express');
const session = require('express-session');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

const GOOGLE_API_KEY = process.env.GOOGLE_API_KEY;
const GOOGLE_CX = process.env.GOOGLE_CX;
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'asdfghjkl';
const SESSION_SECRET = process.env.SESSION_SECRET || 'dev-only-secret-change-this';

if (SESSION_SECRET === 'dev-only-secret-change-this') {
  console.warn('[WARN] Using default SESSION_SECRET. Set SESSION_SECRET in your .env for production.');
}
if (ADMIN_PASSWORD === 'asdfghjkl') {
  console.warn('[WARN] Using default ADMIN_PASSWORD. Set ADMIN_PASSWORD in your .env for production.');
}

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  name: 'bgmi.sid',
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 1000 * 60 * 60 * 4 // 4 hours
  }
}));

// ---------------------------------------------------------------------------
// In-memory storage. Restarting the server clears history/settings.
// This app is a lightweight monitor, not a database-backed service.
// ---------------------------------------------------------------------------
let history = [];
let settings = {
  keywords: [
    'BGMI update',
    'BGMI patch notes',
    'BGMI security update',
    'BGMI anti cheat',
    'BGMI official announcement'
  ],
  maxResults: 10,
  searchIntervalMinutes: 60,
  publicSourceFilter: ''
};

// ---------------------------------------------------------------------------
// Auth middleware
// ---------------------------------------------------------------------------
function requireAuth(req, res, next) {
  if (req.session && req.session.authenticated) {
    return next();
  }
  return res.status(401).json({ error: 'Not authenticated.' });
}

// ---------------------------------------------------------------------------
// Google Custom Search helper
// ---------------------------------------------------------------------------
const ANTI_CHEAT_TERMS = ['anti-cheat', 'anti cheat', 'security update', 'cheat detection'];

async function googleSearch(query, num) {
  if (!GOOGLE_API_KEY || !GOOGLE_CX) {
    throw new Error('MISSING_CREDENTIALS');
  }

  const url = new URL('https://www.googleapis.com/customsearch/v1');
  url.searchParams.set('key', GOOGLE_API_KEY);
  url.searchParams.set('cx', GOOGLE_CX);
  url.searchParams.set('q', query);
  url.searchParams.set('num', String(Math.min(Math.max(num || 5, 1), 10)));
  url.searchParams.set('dateRestrict', 'd1'); // prefer results from the last 24 hours

  let response;
  try {
    response = await fetch(url.toString());
  } catch (networkErr) {
    throw new Error('NETWORK_ERROR');
  }

  if (response.status === 401 || response.status === 403) {
    throw new Error('INVALID_CREDENTIALS');
  }
  if (response.status === 429) {
    throw new Error('QUOTA_EXCEEDED');
  }
  if (!response.ok) {
    throw new Error('SEARCH_FAILED');
  }

  const data = await response.json();
  return Array.isArray(data.items) ? data.items : [];
}

function handleSearchError(err, res) {
  const message = err && err.message ? err.message : 'UNKNOWN';
  console.error('[search error]', message);

  switch (message) {
    case 'MISSING_CREDENTIALS':
      return res.status(500).json({ error: 'Search is not configured yet. Please contact the administrator.' });
    case 'INVALID_CREDENTIALS':
      return res.status(500).json({ error: 'Search service credentials are invalid. Please contact the administrator.' });
    case 'QUOTA_EXCEEDED':
      return res.status(429).json({ error: 'Search quota exceeded. Please try again later.' });
    case 'NETWORK_ERROR':
      return res.status(502).json({ error: 'Could not reach the search service. Check your connection and try again.' });
    case 'SEARCH_FAILED':
      return res.status(502).json({ error: 'The search service returned an error. Please try again shortly.' });
    default:
      return res.status(500).json({ error: 'An unexpected error occurred. Please try again.' });
  }
}

// ---------------------------------------------------------------------------
// Public API
// ---------------------------------------------------------------------------
app.get('/api/check', async (req, res) => {
  const keywords = settings.keywords.length ? settings.keywords : ['BGMI update'];
  const maxResults = settings.maxResults || 10;
  const perKeyword = Math.max(1, Math.ceil(maxResults / keywords.length));

  try {
    const searchResults = await Promise.allSettled(
      keywords.map((keyword) => googleSearch(keyword, perKeyword))
    );

    // If EVERY search failed, surface the first real error to the client.
    const allFailed = searchResults.every((r) => r.status === 'rejected');
    if (allFailed) {
      const firstError = searchResults.find((r) => r.status === 'rejected');
      throw firstError.reason;
    }

    const items = [];
    const seenLinks = new Set();

    searchResults.forEach((result) => {
      if (result.status !== 'fulfilled') return;
      result.value.forEach((item) => {
        if (!item.link || seenLinks.has(item.link)) return;
        seenLinks.add(item.link);
        items.push({
          title: item.title || 'Untitled result',
          snippet: item.snippet || '',
          link: item.link,
          source: item.displayLink || ''
        });
      });
    });

    const trimmedItems = items.slice(0, maxResults);

    let antiCheatMention = false;
    trimmedItems.forEach((item) => {
      const text = `${item.title} ${item.snippet}`.toLowerCase();
      if (ANTI_CHEAT_TERMS.some((term) => text.includes(term))) {
        antiCheatMention = true;
      }
    });

    const activityScore = Math.min(
      100,
      Math.round((trimmedItems.length / Math.max(maxResults, 1)) * 100)
    );

    const checkedAt = new Date();
    const record = {
      date: checkedAt.toISOString().split('T')[0],
      time: checkedAt.toTimeString().split(' ')[0],
      timestamp: checkedAt.toISOString(),
      updateFound: trimmedItems.length > 0,
      antiCheatMention,
      activityScore,
      resultCount: trimmedItems.length
    };

    history.unshift(record);
    if (history.length > 200) history = history.slice(0, 200);

    res.json({
      checkedAt: checkedAt.toISOString(),
      activityScore,
      antiCheatMention,
      resultCount: trimmedItems.length,
      results: trimmedItems,
      disclaimer:
        "This score is calculated from publicly available information and does not represent BGMI's internal anti-cheat status."
    });
  } catch (err) {
    handleSearchError(err, res);
  }
});

app.get('/api/session', (req, res) => {
  res.json({ authenticated: !!(req.session && req.session.authenticated) });
});

// ---------------------------------------------------------------------------
// Admin auth
// ---------------------------------------------------------------------------
app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};

  if (typeof username !== 'string' || typeof password !== 'string') {
    return res.status(400).json({ error: 'Username and password are required.' });
  }

  if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
    req.session.authenticated = true;
    req.session.username = username;
    return res.json({ success: true });
  }

  return res.status(401).json({ error: 'Invalid username or password.' });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('bgmi.sid');
    res.json({ success: true });
  });
});

// ---------------------------------------------------------------------------
// Admin-only API
// ---------------------------------------------------------------------------
app.get('/api/history', requireAuth, (req, res) => {
  res.json({ history });
});

app.get('/api/settings', requireAuth, (req, res) => {
  res.json({ settings });
});

app.post('/api/settings', requireAuth, (req, res) => {
  const { keywords, maxResults, searchIntervalMinutes, publicSourceFilter } = req.body || {};

  if (keywords !== undefined) {
    if (!Array.isArray(keywords) || keywords.some((k) => typeof k !== 'string')) {
      return res.status(400).json({ error: 'Keywords must be a list of text values.' });
    }
    const cleaned = keywords.map((k) => k.trim()).filter((k) => k.length > 0);
    if (cleaned.length === 0) {
      return res.status(400).json({ error: 'At least one keyword is required.' });
    }
    settings.keywords = cleaned;
  }

  if (maxResults !== undefined) {
    const n = parseInt(maxResults, 10);
    if (Number.isNaN(n) || n < 1 || n > 50) {
      return res.status(400).json({ error: 'Maximum results must be a number between 1 and 50.' });
    }
    settings.maxResults = n;
  }

  if (searchIntervalMinutes !== undefined) {
    const n = parseInt(searchIntervalMinutes, 10);
    if (Number.isNaN(n) || n < 1) {
      return res.status(400).json({ error: 'Search interval must be a positive number of minutes.' });
    }
    settings.searchIntervalMinutes = n;
  }

  if (publicSourceFilter !== undefined) {
    if (typeof publicSourceFilter !== 'string') {
      return res.status(400).json({ error: 'Public source filter must be text.' });
    }
    settings.publicSourceFilter = publicSourceFilter;
  }

  res.json({ success: true, settings });
});

app.post('/api/clear-history', requireAuth, (req, res) => {
  history = [];
  res.json({ success: true });
});

app.get('/api/admin-summary', requireAuth, (req, res) => {
  const totalChecks = history.length;
  const publicUpdates = history.filter((h) => h.updateFound).length;
  const antiCheatMentions = history.filter((h) => h.antiCheatMention).length;
  const lastCheck = history[0] || null;

  res.json({
    totalChecks,
    publicUpdates,
    antiCheatMentions,
    currentActivity: lastCheck ? lastCheck.activityScore : 0,
    serverStatus: 'ONLINE',
    lastCheck: lastCheck ? lastCheck.timestamp : null
  });
});

// ---------------------------------------------------------------------------
// Pages
// ---------------------------------------------------------------------------
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// ---------------------------------------------------------------------------
// Fallback handlers
// ---------------------------------------------------------------------------
app.use((req, res) => {
  res.status(404).json({ error: 'Not found.' });
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error('[unhandled error]', err);
  res.status(500).json({ error: 'Internal server error.' });
});

app.listen(PORT, () => {
  console.log(`BGMI Update Monitor running at http://localhost:${PORT}`);
});

(function () {
  'use strict';

  const loginView = document.getElementById('login-view');
  const adminView = document.getElementById('admin-view');
  const loginForm = document.getElementById('login-form');
  const loginError = document.getElementById('login-error');
  const logoutBtn = document.getElementById('logout-btn');

  const navItems = document.querySelectorAll('.nav-item[data-section]');
  const sections = document.querySelectorAll('.admin-section');

  const adminCheckBtn = document.getElementById('admin-check-btn');
  const adminCheckStatus = document.getElementById('admin-check-status');
  const adminResultsList = document.getElementById('admin-results-list');

  const settingsForm = document.getElementById('settings-form');
  const settingsStatus = document.getElementById('settings-status');
  const clearHistoryBtn = document.getElementById('clear-history-btn');

  function showLogin() {
    loginView.classList.remove('hidden');
    adminView.classList.add('hidden');
  }

  function showAdmin() {
    loginView.classList.add('hidden');
    adminView.classList.remove('hidden');
    refreshAll();
  }

  async function checkSession() {
    try {
      const res = await fetch('/api/session');
      const data = await res.json();
      if (data.authenticated) {
        showAdmin();
      } else {
        showLogin();
      }
    } catch (e) {
      showLogin();
    }
  }

  // ---------------- Login ----------------
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    loginError.classList.add('hidden');

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();

      if (!res.ok) {
        loginError.textContent = data.error || 'Login failed.';
        loginError.classList.remove('hidden');
        return;
      }

      loginForm.reset();
      showAdmin();
    } catch (err) {
      loginError.textContent = 'Could not reach the server. Please try again.';
      loginError.classList.remove('hidden');
    }
  });

  logoutBtn.addEventListener('click', async () => {
    try {
      await fetch('/api/logout', { method: 'POST' });
    } catch (e) {
      // ignore network errors on logout
    }
    showLogin();
  });

  // ---------------- Sidebar navigation ----------------
  navItems.forEach((btn) => {
    btn.addEventListener('click', () => {
      navItems.forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');

      const targetId = btn.getAttribute('data-section');
      sections.forEach((s) => {
        s.classList.toggle('hidden', s.id !== targetId);
      });
    });
  });

  // ---------------- Dashboard summary ----------------
  async function loadSummary() {
    try {
      const res = await fetch('/api/admin-summary');
      if (!res.ok) return;
      const data = await res.json();

      document.getElementById('a-total-checks').textContent = String(data.totalChecks);
      document.getElementById('a-public-updates').textContent = String(data.publicUpdates);
      document.getElementById('a-anticheat-mentions').textContent = String(data.antiCheatMentions);
      document.getElementById('a-current-activity').textContent = data.currentActivity + '%';
      document.getElementById('a-server-status').textContent = data.serverStatus;
      document.getElementById('a-last-check').textContent = data.lastCheck
        ? new Date(data.lastCheck).toLocaleString()
        : '—';

      document.getElementById('s-status').textContent = data.serverStatus;
      document.getElementById('s-total').textContent = String(data.totalChecks);
      document.getElementById('s-last-check').textContent = data.lastCheck
        ? new Date(data.lastCheck).toLocaleString()
        : '—';
    } catch (e) {
      // Silent — dashboard just keeps showing last known values.
    }
  }

  // ---------------- History table ----------------
  async function loadHistory() {
    const tbody = document.getElementById('history-body');
    tbody.textContent = '';

    try {
      const res = await fetch('/api/history');
      if (!res.ok) return;
      const data = await res.json();

      if (!data.history || data.history.length === 0) {
        const row = document.createElement('tr');
        const cell = document.createElement('td');
        cell.colSpan = 6;
        cell.textContent = 'No history yet.';
        row.appendChild(cell);
        tbody.appendChild(row);
        return;
      }

      data.history.forEach((record) => {
        const row = document.createElement('tr');

        const cells = [
          record.date,
          record.time,
          record.updateFound ? 'YES' : 'NO',
          record.antiCheatMention ? 'YES' : 'NO',
          record.activityScore + '%',
          String(record.resultCount)
        ];

        cells.forEach((value) => {
          const td = document.createElement('td');
          td.textContent = value;
          row.appendChild(td);
        });

        tbody.appendChild(row);
      });
    } catch (e) {
      // Silent — table just stays empty on failure.
    }
  }

  // ---------------- Settings ----------------
  async function loadSettings() {
    try {
      const res = await fetch('/api/settings');
      if (!res.ok) return;
      const data = await res.json();
      const s = data.settings;

      document.getElementById('settings-keywords').value = (s.keywords || []).join('\n');
      document.getElementById('settings-max-results').value = s.maxResults;
      document.getElementById('settings-interval').value = s.searchIntervalMinutes;
      document.getElementById('settings-source-filter').value = s.publicSourceFilter || '';
    } catch (e) {
      // Silent — form just stays empty.
    }
  }

  settingsForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    settingsStatus.textContent = 'Saving...';

    const keywords = document.getElementById('settings-keywords').value
      .split('\n')
      .map((k) => k.trim())
      .filter((k) => k.length > 0);

    const payload = {
      keywords,
      maxResults: document.getElementById('settings-max-results').value,
      searchIntervalMinutes: document.getElementById('settings-interval').value,
      publicSourceFilter: document.getElementById('settings-source-filter').value
    };

    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();

      if (!res.ok) {
        settingsStatus.textContent = data.error || 'Could not save settings.';
        return;
      }

      settingsStatus.textContent = 'Settings saved.';
    } catch (err) {
      settingsStatus.textContent = 'Could not reach the server.';
    }
  });

  clearHistoryBtn.addEventListener('click', async () => {
    if (!confirm('Clear all local activity history? This cannot be undone.')) return;

    try {
      const res = await fetch('/api/clear-history', { method: 'POST' });
      if (res.ok) {
        loadHistory();
        loadSummary();
      }
    } catch (e) {
      // Silent
    }
  });

  // ---------------- Manual check from admin ----------------
  function renderAdminResults(results) {
    adminResultsList.textContent = '';

    if (!results || results.length === 0) {
      const empty = document.createElement('p');
      empty.className = 'empty-state';
      empty.textContent = 'No public results found for this check.';
      adminResultsList.appendChild(empty);
      return;
    }

    results.forEach((item) => {
      const card = document.createElement('div');
      card.className = 'result-card';

      const heading = document.createElement('h3');
      const link = document.createElement('a');
      link.href = item.link;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.textContent = item.title;
      heading.appendChild(link);

      const snippet = document.createElement('p');
      snippet.textContent = item.snippet || '';

      const meta = document.createElement('span');
      meta.className = 'result-meta';
      meta.textContent = item.source || '';

      card.appendChild(heading);
      card.appendChild(snippet);
      card.appendChild(meta);
      adminResultsList.appendChild(card);
    });
  }

  adminCheckBtn.addEventListener('click', async () => {
    adminCheckBtn.disabled = true;
    adminCheckBtn.textContent = 'CHECKING...';
    adminCheckStatus.textContent = '';

    try {
      const res = await fetch('/api/check');
      const data = await res.json();

      if (!res.ok) {
        adminCheckStatus.textContent = data.error || 'Check failed.';
        return;
      }

      renderAdminResults(data.results);
      adminCheckStatus.textContent = 'Checked at ' + new Date(data.checkedAt).toLocaleString();

      loadSummary();
      loadHistory();
    } catch (err) {
      adminCheckStatus.textContent = 'Could not reach the server.';
    } finally {
      adminCheckBtn.disabled = false;
      adminCheckBtn.textContent = 'RUN CHECK NOW';
    }
  });

  function refreshAll() {
    loadSummary();
    loadHistory();
    loadSettings();
  }

  checkSession();
})();

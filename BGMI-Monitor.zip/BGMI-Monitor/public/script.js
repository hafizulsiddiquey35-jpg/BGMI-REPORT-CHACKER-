(function () {
  'use strict';

  const checkBtn = document.getElementById('check-btn');
  const checkTimeEl = document.getElementById('check-time');
  const errorBanner = document.getElementById('error-banner');

  const statToday = document.getElementById('stat-today');
  const statActivity = document.getElementById('stat-activity');
  const statAntiCheat = document.getElementById('stat-anticheat');
  const statResults = document.getElementById('stat-results');

  const activityBar = document.getElementById('activity-bar');
  const antiCheatStatus = document.getElementById('anticheat-status');
  const resultsList = document.getElementById('results-list');

  let antiCheatMentionCount = 0;
  let chart = null;

  function showError(message) {
    errorBanner.textContent = message;
    errorBanner.classList.remove('hidden');
  }

  function clearError() {
    errorBanner.textContent = '';
    errorBanner.classList.add('hidden');
  }

  function formatTime(iso) {
    try {
      return new Date(iso).toLocaleString();
    } catch (e) {
      return iso;
    }
  }

  function renderResults(results) {
    resultsList.textContent = ''; // clear safely

    if (!results || results.length === 0) {
      const empty = document.createElement('p');
      empty.className = 'empty-state';
      empty.textContent = 'No public results found for this check.';
      resultsList.appendChild(empty);
      return;
    }

    results.forEach((item) => {
      const card = document.createElement('div');
      card.className = 'result-card';

      const heading = document.createElement('h3');
      const link = document.createElement('a');
      link.href = item.link;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.textContent = item.title; // textContent only, never innerHTML
      heading.appendChild(link);

      const snippet = document.createElement('p');
      snippet.textContent = item.snippet || '';

      const meta = document.createElement('span');
      meta.className = 'result-meta';
      meta.textContent = item.source || '';

      card.appendChild(heading);
      card.appendChild(snippet);
      card.appendChild(meta);
      resultsList.appendChild(card);
    });
  }

  function initChart() {
    const ctx = document.getElementById('activity-chart');
    if (!ctx || typeof Chart === 'undefined') return;

    const years = ['2017', '2018', '2019', '2020', '2021', '2022', '2023', '2024', '2025', '2026'];
    const placeholderData = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];

    chart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: years,
        datasets: [{
          label: 'Public Activity Score',
          data: placeholderData,
          borderColor: '#f2b705',
          backgroundColor: 'rgba(242, 183, 5, 0.15)',
          tension: 0.3,
          fill: true,
          pointRadius: 3
        }]
      },
      options: {
        responsive: true,
        scales: {
          y: {
            min: 0,
            max: 100,
            ticks: { color: '#9a9ea8', callback: (v) => v + '%' },
            grid: { color: '#2a2d35' }
          },
          x: {
            ticks: { color: '#9a9ea8' },
            grid: { color: '#2a2d35' }
          }
        },
        plugins: {
          legend: { labels: { color: '#f5f5f5' } }
        }
      }
    });
  }

  function updateChartLatestYear(score) {
    if (!chart) return;
    const lastIndex = chart.data.datasets[0].data.length - 1;
    chart.data.datasets[0].data[lastIndex] = score;
    chart.update();
  }

  async function runCheck() {
    clearError();
    checkBtn.disabled = true;
    checkBtn.textContent = 'CHECKING...';

    try {
      const response = await fetch('/api/check');
      const data = await response.json();

      if (!response.ok) {
        showError(data.error || 'Something went wrong while checking for updates.');
        statToday.textContent = 'CHECK FAILED';
        return;
      }

      statToday.textContent = 'CHECKED';
      statActivity.textContent = data.activityScore + '%';
      statResults.textContent = String(data.resultCount);

      if (data.antiCheatMention) {
        antiCheatMentionCount += 1;
      }
      statAntiCheat.textContent = String(antiCheatMentionCount);

      activityBar.style.width = data.activityScore + '%';

      if (data.antiCheatMention) {
        antiCheatStatus.textContent = 'MENTION FOUND';
        antiCheatStatus.className = 'anticheat-status found';
      } else {
        antiCheatStatus.textContent = 'NO NEW MENTION';
        antiCheatStatus.className = 'anticheat-status neutral';
      }

      renderResults(data.results);
      updateChartLatestYear(data.activityScore);

      checkTimeEl.textContent = 'Last checked: ' + formatTime(data.checkedAt);
    } catch (err) {
      showError('Could not reach the server. Please check your connection and try again.');
      statToday.textContent = 'CHECK FAILED';
    } finally {
      checkBtn.disabled = false;
      checkBtn.textContent = "CHECK TODAY'S UPDATE";
    }
  }

  checkBtn.addEventListener('click', runCheck);

  initChart();
})();
